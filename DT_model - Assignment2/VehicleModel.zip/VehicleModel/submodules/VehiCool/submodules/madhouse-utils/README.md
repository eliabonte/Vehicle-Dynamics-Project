# MadHouse utils

MadHouse utils is a repository for all the utilities developed by the MadHouse for any of the programming languages we use.

## License

We release this library under the [BSD 2-Clause License](LICENSE).

## Authorship

Throughout this library we use the following scheme for authorship.

- Authors:
  - Name Surname of author 1
  - Name Surname of author 2
  - …

This is written in the header of each file. The order of the authors reflects the contributions of each author to the specific file.