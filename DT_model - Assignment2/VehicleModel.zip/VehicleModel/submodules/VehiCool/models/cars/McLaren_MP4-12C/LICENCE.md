# LICENCE

McLaren MP4-12C by [stunner2211](https://www.thingiverse.com/stunner2211) is licensed under the [Creative Commons - Attribution - Non-Commercial - Share Alike](https://creativecommons.org/licenses/by-nc-sa/4.0/) licence.

Download link [McLaren MP4-12C](https://www.thingiverse.com/thing:2019267).