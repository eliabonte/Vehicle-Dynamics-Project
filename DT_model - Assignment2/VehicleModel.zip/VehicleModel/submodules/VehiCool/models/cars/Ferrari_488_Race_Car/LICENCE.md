# LICENCE

Ferrari_488_Race_Car by [stunner2211](https://www.thingiverse.com/stunner2211) is licensed under the [Creative Commons - Attribution - Non-Commercial - Share Alike](https://creativecommons.org/licenses/by-nc-sa/4.0/) licence.

Download link [Ferrari_488_Race_Car](https://www.thingiverse.com/thing:2946483).