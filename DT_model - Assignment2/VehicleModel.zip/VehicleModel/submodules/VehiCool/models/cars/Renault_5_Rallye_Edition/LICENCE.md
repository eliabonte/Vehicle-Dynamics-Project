# LICENCE

Renault 5 Rallye Edition by [stunner2211](https://www.thingiverse.com/stunner2211) is licensed under the [Creative Commons - Attribution - Non-Commercial - Share Alike](https://creativecommons.org/licenses/by-nc-sa/4.0/) licence.

Download link [Renault 5 Rallye Edition](https://www.thingiverse.com/thing:2165974).

The modifications applied to the STL files are the following:

- translation and rotation of `Renault_5_Rallye_Edition.stl`;
- translation and rotation of `Renault_5_Rallye_Edition_Body.stl`;
- translation and rotation of `Renault_5_Rallye_Edition_Wheel.stl`.
