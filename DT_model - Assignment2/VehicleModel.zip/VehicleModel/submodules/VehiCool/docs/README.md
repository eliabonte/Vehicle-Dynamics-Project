# Documentation

This library is still under development. At the moment the documentation is not available. In the meantime, you can refer to the [`examples`](../examples/README.md) folder and to the [`source code`](../src) which are well documented. In addition, you can refer to the [`FEATURES.md`](FEATURES.md) file which describes the implemented features in detail.

## License

We release this library under the [BSD 2-Clause License](LICENSE).

## Authorship

Throughout this library we use the following scheme for authorship.

- Authors:
  - Name Surname of author 1
  - Name Surname of author 2
  - …

This is written in the header of each file. The order of the authors reflects the contributions of each author to the specific file.